# riscv_sv

A simple 32-bit 5-stage RISC-V processor in SystemVerilog based on the book Computer Organization and Design by Patterson &amp; Hennesy.

For more information you can check out the book:
[here](https://www.amazon.com/gp/product/0128122757/ref=dbs_a_def_rwt_bibl_vppi_i2).
